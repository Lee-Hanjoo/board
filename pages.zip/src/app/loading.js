
export default async function Loading(props) {
    return (
        <h4>로딩중...</h4>
    )
}